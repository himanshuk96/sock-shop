See the [documentation](https://microservices-demo.github.io/deployment/minimeos-marathon.html) on how to deploy Sock Shop using [minimesos](https://minimesos.org) and [Marathon](https://github.com/mesosphere/marathon).








