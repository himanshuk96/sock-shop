See the [documentation](https://microservices-demo.github.io/deployment/apcera.html) on how to deploy Sock Shop on Apcera.
