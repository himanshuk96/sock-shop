See the [documentation](https://microservices-demo.github.io/deployment/docker-compose-weave.html) on how to deploy Sock Shop using Docker Compose and Weave.
