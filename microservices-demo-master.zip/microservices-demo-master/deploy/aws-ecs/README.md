See the [documentation](https://microservices-demo.github.io/deployment/ecs.html) on how to deploy Sock Shop using AWS ECS.
